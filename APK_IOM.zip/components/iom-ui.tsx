import type { ReactNode } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View, type TextInputProps, type ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export const C = {
  canvas: "#F5F5EF",
  paper: "#FFFFFF",
  ink: "#142F2D",
  muted: "#6E7C79",
  faint: "#91A09C",
  line: "#E1E6DF",
  teal: "#26B7A4",
  tealPale: "#DDF3EF",
  lime: "#E5F0BE",
  limeInk: "#3C5422",
  blue: "#DDEBFA",
  blueInk: "#365A81",
  orange: "#F8E7D5",
  orangeInk: "#9B5C2F",
  purple: "#ECE5F5",
  purpleInk: "#684D81",
  danger: "#B75445",
  dangerPale: "#F9E8E3",
  dark: "#102D2A",
};

export function Screen({ children, scroll = true, style }: { children: ReactNode; scroll?: boolean; style?: ViewStyle }) {
  return (
    <SafeAreaView style={[styles.safe, style]} edges={["top"]}>
      {scroll ? <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">{children}</ScrollView> : <View style={styles.content}>{children}</View>}
    </SafeAreaView>
  );
}

export function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return <Text style={[styles.eyebrow, light && { color: "#A6C7C0" }]}>{children}</Text>;
}

export function Card({ children, style, dark = false }: { children: ReactNode; style?: ViewStyle; dark?: boolean }) {
  return <View style={[styles.card, dark && styles.darkCard, style]}>{children}</View>;
}

export function SectionTitle({ title, detail, action }: { title: string; detail?: string; action?: ReactNode }) {
  return <View style={styles.sectionRow}><View style={{ flex: 1 }}><Text style={styles.sectionTitle}>{title}</Text>{detail ? <Text style={styles.sectionDetail}>{detail}</Text> : null}</View>{action}</View>;
}

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "teal" | "lime" | "blue" | "orange" | "purple" | "danger" }) {
  const colors = { neutral: ["#EEF1EC", C.ink], teal: [C.tealPale, "#16685D"], lime: [C.lime, C.limeInk], blue: [C.blue, C.blueInk], orange: [C.orange, C.orangeInk], purple: [C.purple, C.purpleInk], danger: [C.dangerPale, C.danger] } as const;
  return <View style={[styles.badge, { backgroundColor: colors[tone][0] }]}><Text style={[styles.badgeText, { color: colors[tone][1] }]}>{children}</Text></View>;
}

export function ActionButton({ title, onPress, secondary = false, disabled = false, icon, accessibilityLabel }: { title: string; onPress: () => void; secondary?: boolean; disabled?: boolean; icon?: ReactNode; accessibilityLabel?: string }) {
  return <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? title} style={({ pressed }) => [styles.action, secondary ? styles.actionSecondary : styles.actionPrimary, disabled && { opacity: 0.45 }, pressed && !disabled && { opacity: 0.82, transform: [{ scale: 0.99 }] }]}><View style={styles.actionInner}>{icon}{<Text style={[styles.actionText, secondary && { color: C.ink }]}>{title}</Text>}</View></Pressable>;
}

export function Field({ label, hint, multiline, style, ...props }: TextInputProps & { label: string; hint?: string }) {
  return <View style={{ gap: 7 }}><Text style={styles.fieldLabel}>{label}</Text><TextInput accessibilityLabel={label} placeholderTextColor="#98A49E" multiline={multiline} textAlignVertical={multiline ? "top" : "center"} style={[styles.input, multiline && styles.textArea, style]} {...props} />{hint ? <Text style={styles.helper}>{hint}</Text> : null}</View>;
}

export function ProgressLine({ value, color = C.teal }: { value: number; color?: string }) {
  return <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: value }} accessibilityLabel={`Cobertura ${value} por ciento`} style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.max(0, Math.min(100, value))}%`, backgroundColor: color }]} /></View>;
}

export const ui = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 10 },
  spread: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  muted: { color: C.muted, fontSize: 13, lineHeight: 20 },
  body: { color: C.ink, fontSize: 15, lineHeight: 23 },
  small: { color: C.muted, fontSize: 12, lineHeight: 18 },
  divider: { height: 1, backgroundColor: C.line, marginVertical: 14 },
});

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.canvas },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 14, paddingBottom: 30, gap: 17 },
  eyebrow: { color: C.teal, fontSize: 10, fontWeight: "800", letterSpacing: 1.7, textTransform: "uppercase" },
  card: { backgroundColor: C.paper, borderRadius: 22, padding: 18, borderWidth: 1, borderColor: C.line, gap: 12 },
  darkCard: { backgroundColor: C.dark, borderColor: C.dark },
  sectionRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 2 },
  sectionTitle: { color: C.ink, fontSize: 20, fontWeight: "700", letterSpacing: -0.45 },
  sectionDetail: { color: C.muted, fontSize: 13, lineHeight: 19, marginTop: 3 },
  badge: { alignSelf: "flex-start", paddingVertical: 6, paddingHorizontal: 10, borderRadius: 999, minHeight: 28, justifyContent: "center" },
  badgeText: { fontSize: 11, fontWeight: "700", letterSpacing: 0.1 },
  action: { minHeight: 50, borderRadius: 16, justifyContent: "center", paddingHorizontal: 17 },
  actionPrimary: { backgroundColor: C.dark },
  actionSecondary: { backgroundColor: C.paper, borderWidth: 1, borderColor: C.line },
  actionInner: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 9 },
  actionText: { color: "#FFFFFF", fontWeight: "700", fontSize: 14 },
  fieldLabel: { fontSize: 13, color: C.ink, fontWeight: "700" },
  input: { minHeight: 48, paddingHorizontal: 14, borderWidth: 1, borderColor: C.line, borderRadius: 14, color: C.ink, backgroundColor: C.paper, fontSize: 14 },
  textArea: { minHeight: 88, paddingVertical: 12 },
  helper: { color: C.muted, fontSize: 12, lineHeight: 18 },
  progressTrack: { height: 7, backgroundColor: "#E9EDE7", borderRadius: 99, overflow: "hidden" },
  progressFill: { height: 7, borderRadius: 99 },
});
