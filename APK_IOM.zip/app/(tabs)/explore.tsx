import { Feather } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Badge, C, Card, Eyebrow, Screen, SectionTitle, ui } from "@/components/iom-ui";
import { formalRelation, PERSPECTIVES, TRIADS, type Phase } from "@/lib/iom-spec";

const phaseNames: Record<Phase, string> = { adv: "Avance", ret: "Retroceso" };
const positionNames = ["Individualidad", "Dualidad", "Totalidad"];
const toneColors = [C.teal, C.blueInk, C.limeInk];

function RelationNodePicker({ label, phase, position, triad, onPhase, onPosition }: { label: string; phase: Phase; position: number; triad: { advance: [string, string, string]; reverse: [string, string, string] }; onPhase: (phase: Phase) => void; onPosition: (position: number) => void }) {
  const labels = phase === "adv" ? triad.advance : triad.reverse;
  return <View style={styles.nodePicker}>
    <Text style={styles.nodePickerTitle}>{label}</Text>
    <View style={styles.phaseSegment}>{(["adv", "ret"] as const).map((option) => <Pressable key={option} onPress={() => onPhase(option)} accessibilityRole="button" accessibilityState={{ selected: phase === option }} style={[styles.phaseButton, phase === option && styles.phaseButtonActive]}><Text style={[styles.phaseButtonText, phase === option && styles.phaseButtonTextActive]}>{phaseNames[option]}</Text></Pressable>)}</View>
    <View style={styles.nodePositions}>{labels.map((node, index) => <Pressable key={`${node}-${index}`} onPress={() => onPosition(index)} accessibilityRole="button" accessibilityState={{ selected: position === index }} accessibilityLabel={`${label}: posición ${index}, ${positionNames[index]}, ${node}`} style={[styles.nodePosition, position === index && styles.nodePositionActive]}><Text style={[styles.nodeIndex, { color: toneColors[index] }]}>{index}</Text><Text numberOfLines={2} style={styles.nodeName}>{node}</Text></Pressable>)}</View>
  </View>;
}

export default function ExploreScreen() {
  const [query, setQuery] = useState("");
  const [phase, setPhase] = useState<Phase>("adv");
  const [expanded, setExpanded] = useState<number | null>(1);
  const [sourcePhase, setSourcePhase] = useState<Phase>("adv");
  const [targetPhase, setTargetPhase] = useState<Phase>("ret");
  const [sourcePosition, setSourcePosition] = useState(0);
  const [targetPosition, setTargetPosition] = useState(2);
  const filtered = useMemo(() => TRIADS.filter((triad) => `${triad.advance.join(" ")} ${triad.reverse.join(" ")} ${triad.index}`.toLowerCase().includes(query.trim().toLowerCase())), [query]);
  const relationTriad = TRIADS.find((triad) => triad.index === expanded) ?? TRIADS[0];
  const relationType = formalRelation({ phase: sourcePhase, position: sourcePosition }, { phase: targetPhase, position: targetPosition });
  const resultText = relationType === "mirrorOf" ? "Par espejo: posiciones simétricas en fases opuestas." : relationType === "creates" ? "Crea: una fase opuesta conecta el centro con una posición lateral." : "none: la regla no asigna relación en este par.";

  return (
    <Screen>
      <View style={styles.header}><Eyebrow>CARTOGRAFÍA IOM · 78 NODOS</Eyebrow><Text style={styles.title}>Explorar el{`\n`}marco</Text><Text style={styles.subtitle}>Perspectivas, posiciones y relaciones para seguir una unidad a través de su transformación.</Text></View>
      <Card style={styles.searchCard}><Feather name="search" size={17} color={C.faint} /><TextInput value={query} onChangeText={setQuery} placeholder="Buscar una tríada o concepto" placeholderTextColor={C.faint} accessibilityLabel="Buscar una tríada o concepto" style={styles.searchInput} /></Card>
      <View style={styles.phaseCard}><View style={{ flex: 1 }}><Text style={styles.phaseLabel}>Sentido del recorrido</Text><Text style={ui.small}>La posición central mantiene el contraste.</Text></View><View style={styles.segment}><Pressable onPress={() => setPhase("adv")} accessibilityRole="button" accessibilityState={{ selected: phase === "adv" }} style={[styles.segmentButton, phase === "adv" && styles.segmentActive]}><Text style={[styles.segmentText, phase === "adv" && styles.segmentTextActive]}>Avance →</Text></Pressable><Pressable onPress={() => setPhase("ret")} accessibilityRole="button" accessibilityState={{ selected: phase === "ret" }} style={[styles.segmentButton, phase === "ret" && styles.segmentActive]}><Text style={[styles.segmentText, phase === "ret" && styles.segmentTextActive]}>← Retorno</Text></Pressable></View></View>
      <View style={styles.summaryRow}><SectionTitle title="Las 13 tríadas" detail={`${filtered.length} resultado(s) · fase de ${phaseNames[phase].toLowerCase()}.`} /><Badge tone="teal">01—13</Badge></View>
      {filtered.map((triad) => {
        const open = expanded === triad.index;
        const labels = phase === "adv" ? triad.advance : triad.reverse;
        return <Pressable key={triad.index} onPress={() => setExpanded(open ? null : triad.index)} accessibilityRole="button" accessibilityState={{ expanded: open }} accessibilityLabel={`Tríada ${triad.index}: ${labels.join(", ")}`} style={({ pressed }) => [styles.triadCard, open && styles.triadOpen, pressed && { opacity: 0.9 }]}>
          <View style={styles.triadTop}><View style={styles.triadIndex}><Text style={styles.triadIndexText}>{String(triad.index).padStart(2, "0")}</Text></View><View style={{ flex: 1 }}><Text style={styles.triadName}>{labels[0]} <Text style={styles.nameSeparator}>·</Text> {labels[1]} <Text style={styles.nameSeparator}>·</Text> {labels[2]}</Text><Text style={styles.triadMeta}>{open ? "Distinción · relación · integración" : `Tríada ${String(triad.index).padStart(2, "0")} · ${phaseNames[phase]}`}</Text></View><Feather name={open ? "chevron-up" : "chevron-down"} size={18} color={C.muted} /></View>
          {open ? <View style={styles.triadDetail}><View style={styles.positionRow}>{labels.map((node, position) => <View key={`${node}-${position}`} style={styles.positionCell}><Text style={[styles.positionIndex, { color: toneColors[position] }]}>{position === 1 ? "0" : phase === "adv" ? "→" : "←"}</Text><View style={[styles.positionDot, { backgroundColor: [C.tealPale, C.blue, C.lime][position] }]}><Text style={[styles.positionLetter, { color: toneColors[position] }]}>{["I", "D", "T"][position]}</Text></View><Text style={styles.positionName}>{positionNames[position]}</Text><Text style={styles.positionLabel}>{node}</Text></View>)}</View><Text style={styles.traceNote}>Posición 0 y 2 comparten flecha en los CSV; el índice las mantiene distintas.</Text></View> : null}
        </Pressable>;
      })}
      {filtered.length === 0 ? <Card><Text style={styles.emptyTitle}>No hay coincidencias.</Text><Text style={ui.muted}>Prueba con otra etiqueta o limpia la búsqueda.</Text></Card> : null}

      <View style={{ marginTop: 8 }}><SectionTitle title="Cinco perspectivas" detail="Tres modos posicionales y dos vectores de flujo." /></View>
      {PERSPECTIVES.map((item, index) => {
        const tones = ["teal", "blue", "lime", "orange", "purple"] as const;
        const icons = ["circle", "repeat", "layers", "trending-up", "rotate-ccw"] as const;
        return <Card key={item.id} style={styles.perspectiveCard}><View style={[styles.perspectiveIcon, { backgroundColor: [C.tealPale, C.blue, C.lime, C.orange, C.purple][index] }]}><Feather name={icons[index]} size={16} color={[C.teal, C.blueInk, C.limeInk, C.orangeInk, C.purpleInk][index]} /></View><View style={{ flex: 1, gap: 3 }}><View style={styles.perspectiveHeading}><Text style={styles.perspectiveName}>{item.name}</Text><Badge tone={tones[index]}>{item.kind}</Badge></View><Text style={ui.muted}>{item.role}</Text></View></Card>;
      })}

      <View style={{ marginTop: 8 }}><SectionTitle title="Prueba una relación" detail={`Par de nodos de la tríada ${relationTriad.index} seleccionada.`} /></View>
      <Card style={styles.labCard}>
        <View style={styles.nodePair}><RelationNodePicker label="ORIGEN" phase={sourcePhase} position={sourcePosition} triad={relationTriad} onPhase={setSourcePhase} onPosition={setSourcePosition} /><View style={styles.pairArrow}><Feather name="arrow-right" size={18} color={C.teal} /></View><RelationNodePicker label="OBJETIVO" phase={targetPhase} position={targetPosition} triad={relationTriad} onPhase={setTargetPhase} onPosition={setTargetPosition} /></View>
        <View style={styles.relationResult}><View style={{ flex: 1, gap: 3 }}><Text style={styles.resultTitle}>{relationType}</Text><Text style={styles.resultCopy}>{resultText}</Text></View><Badge tone={relationType === "mirrorOf" ? "blue" : relationType === "creates" ? "lime" : "neutral"}>{relationType}</Badge></View>
        <Text style={styles.relationFoot}>Aplicación de `formalRelation` sobre fase y posición del par seleccionado; no valida si su significado corresponde a un proceso del mundo real.</Text>
      </Card>

      <Card style={styles.relationCard}><View style={styles.relationHead}><View style={styles.relationMark}><Feather name="shuffle" size={16} color={C.teal} /></View><View><Eyebrow>REGLAS DE RELACIÓN</Eyebrow><Text style={styles.relationTitle}>Cómo se enlazan</Text></View></View><View style={styles.ruleRow}><Badge tone="blue">mirrorOf</Badge><Text style={styles.ruleText}>Fases opuestas y posición objetivo = 2 − posición origen.</Text></View><View style={styles.ruleRow}><Badge tone="lime">creates</Badge><Text style={styles.ruleText}>Fases opuestas y un paso entre lateral y centro.</Text></View><View style={styles.ruleRow}><Badge>none</Badge><Text style={styles.ruleText}>En los demás casos, no se asigna relación formal.</Text></View><Text style={styles.relationFoot}>Reglas del núcleo IOM que usa el simulador; esta pantalla no ejecuta un pipeline de validación externo.</Text></Card>
      <Text style={styles.footer}>Catálogo 1.9.0 · El índice de tríada es ordinal, no una identidad.</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 8, paddingTop: 7, paddingBottom: 2 }, title: { fontSize: 35, lineHeight: 38, letterSpacing: -1, fontWeight: "700", color: C.ink }, subtitle: { color: C.muted, fontSize: 14, lineHeight: 21, maxWidth: 350 },
  searchCard: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 52, paddingVertical: 8, borderRadius: 16 }, searchInput: { flex: 1, color: C.ink, fontSize: 14, paddingVertical: 7 },
  phaseCard: { backgroundColor: "#EEF1E9", borderRadius: 18, padding: 12, gap: 10 }, phaseLabel: { color: C.ink, fontSize: 13, fontWeight: "700" }, segment: { flexDirection: "row", padding: 3, backgroundColor: "#DCE2DA", borderRadius: 13 }, segmentButton: { flex: 1, minHeight: 38, justifyContent: "center", alignItems: "center", borderRadius: 10 }, segmentActive: { backgroundColor: C.paper }, segmentText: { color: C.muted, fontSize: 12, fontWeight: "600" }, segmentTextActive: { color: C.ink, fontWeight: "800" },
  summaryRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }, triadCard: { backgroundColor: C.paper, borderWidth: 1, borderColor: C.line, borderRadius: 19, padding: 14, gap: 13 }, triadOpen: { borderColor: "#B6DDD2" }, triadTop: { flexDirection: "row", alignItems: "center", gap: 11 }, triadIndex: { width: 37, height: 37, borderRadius: 13, backgroundColor: C.dark, alignItems: "center", justifyContent: "center" }, triadIndexText: { color: C.lime, fontSize: 13, fontWeight: "800" }, triadName: { color: C.ink, fontSize: 13, fontWeight: "700", textTransform: "capitalize" }, nameSeparator: { color: C.teal }, triadMeta: { color: C.muted, fontSize: 11, marginTop: 4 },
  triadDetail: { paddingTop: 4, gap: 10 }, positionRow: { flexDirection: "row", alignItems: "stretch", gap: 7 }, positionCell: { flex: 1, alignItems: "center", paddingVertical: 12, paddingHorizontal: 3, borderRadius: 14, backgroundColor: C.canvas, gap: 4 }, positionIndex: { fontSize: 17, fontWeight: "700" }, positionDot: { width: 27, height: 27, borderRadius: 10, alignItems: "center", justifyContent: "center" }, positionLetter: { fontSize: 11, fontWeight: "800" }, positionName: { textAlign: "center", fontSize: 9, color: C.muted, fontWeight: "600" }, positionLabel: { textAlign: "center", color: C.ink, fontSize: 11, fontWeight: "700", textTransform: "capitalize" }, traceNote: { fontSize: 10, color: C.muted, lineHeight: 15 },
  emptyTitle: { color: C.ink, fontSize: 15, fontWeight: "700" }, perspectiveCard: { flexDirection: "row", alignItems: "center", gap: 12 }, perspectiveIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, perspectiveHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 5 }, perspectiveName: { color: C.ink, fontSize: 14, fontWeight: "700" },
  labCard: { gap: 12, padding: 13 }, nodePair: { flexDirection: "row", alignItems: "center", gap: 5 }, nodePicker: { flex: 1, gap: 8, minWidth: 0 }, nodePickerTitle: { color: C.muted, fontSize: 9, fontWeight: "800", letterSpacing: 1 }, phaseSegment: { flexDirection: "row", gap: 3, padding: 3, backgroundColor: "#E7ECE5", borderRadius: 10 }, phaseButton: { flex: 1, minHeight: 35, paddingHorizontal: 3, alignItems: "center", justifyContent: "center", borderRadius: 8 }, phaseButtonActive: { backgroundColor: C.paper, borderWidth: 1, borderColor: C.line }, phaseButtonText: { fontSize: 9, color: C.muted, fontWeight: "600" }, phaseButtonTextActive: { color: C.ink, fontWeight: "800" }, nodePositions: { gap: 4 }, nodePosition: { minHeight: 42, borderRadius: 9, backgroundColor: C.canvas, borderWidth: 1, borderColor: "transparent", paddingHorizontal: 6, paddingVertical: 5, flexDirection: "row", alignItems: "center", gap: 6 }, nodePositionActive: { backgroundColor: C.tealPale, borderColor: "#A9D6C9" }, nodeIndex: { fontSize: 12, fontWeight: "800", width: 12 }, nodeName: { flex: 1, color: C.ink, fontSize: 9, lineHeight: 12, fontWeight: "600" }, pairArrow: { width: 22, alignItems: "center" }, relationResult: { flexDirection: "row", alignItems: "center", gap: 8, padding: 11, borderRadius: 13, backgroundColor: C.dark }, resultTitle: { color: C.paper, fontSize: 16, fontWeight: "800" }, resultCopy: { color: "#C4D4CF", fontSize: 10, lineHeight: 15 }, relationCard: { backgroundColor: "#F0F3EB", borderColor: "#D9E2D6" }, relationHead: { flexDirection: "row", alignItems: "center", gap: 10 }, relationMark: { width: 34, height: 34, borderRadius: 11, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center" }, relationTitle: { color: C.ink, fontSize: 16, fontWeight: "700", marginTop: 3 }, ruleRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 }, ruleText: { flex: 1, color: C.ink, fontSize: 12, lineHeight: 18, paddingTop: 4 }, relationFoot: { color: C.muted, fontSize: 11, lineHeight: 16, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 10 }, footer: { color: C.faint, fontSize: 10, textAlign: "center", marginTop: 2 },
});
