import { Feather } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { C } from "@/components/iom-ui";

const tabs = [
  { name: "index", title: "Inicio", icon: "home" as const },
  { name: "explore", title: "Explorar", icon: "compass" as const },
  { name: "analyze", title: "Analizar", icon: "git-branch" as const },
  { name: "method", title: "Método", icon: "activity" as const },
];

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 7 : Math.max(insets.bottom, 8);
  const tabBarHeight = 57 + bottomPadding;
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: C.teal,
      tabBarInactiveTintColor: C.faint,
      tabBarLabelStyle: { fontSize: 10, fontWeight: "700", marginBottom: 4 },
      tabBarStyle: { backgroundColor: "#FFFFFF", borderTopColor: C.line, borderTopWidth: 1, height: tabBarHeight, paddingTop: 8, paddingBottom: bottomPadding },
    }}>
      {tabs.map((tab) => <Tabs.Screen key={tab.name} name={tab.name} options={{ title: tab.title, tabBarAccessibilityLabel: tab.title, tabBarIcon: ({ color, size }) => <Feather name={tab.icon} color={color} size={size} /> }} />)}
    </Tabs>
  );
}
