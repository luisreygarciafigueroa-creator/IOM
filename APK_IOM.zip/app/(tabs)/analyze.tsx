import { Feather } from "@expo/vector-icons";
import { useEffect, useMemo, useState } from "react";
import { KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { ActionButton, Badge, C, Card, Eyebrow, Field, ProgressLine, Screen, SectionTitle, ui } from "@/components/iom-ui";
import { ProposalReviewCard } from "@/components/proposal-review-card";
import { inspectProcess } from "@/lib/iom-engine";
import { getPerspectiveName, PERSPECTIVES, type Phase, type PerspectiveId } from "@/lib/iom-spec";
import { createEmptyDraft, loadDraft, saveDraft, type ProcessDraft, type Proposal, type ProposalStatus } from "@/lib/storage";

const fieldRows = [
  { key: "context", label: "Contexto", placeholder: "¿Dónde ocurre y qué lo activa?" },
  { key: "inputs", label: "Entradas y señales", placeholder: "Documentos, mensajes, datos, solicitudes…" },
  { key: "actors", label: "Actores y responsables", placeholder: "Personas, roles o sistemas que participan." },
  { key: "constraints", label: "Restricciones y excepciones", placeholder: "Permisos, plazos, límites, pasos que requieren revisión…" },
  { key: "expectedOutput", label: "Resultado esperado", placeholder: "¿Qué debe quedar resuelto o producido?" },
  { key: "successMetric", label: "Métrica de éxito", placeholder: "Ej. tiempo medio de resolución, porcentaje de errores…" },
  { key: "baseline", label: "Línea base actual", placeholder: "Valor medido hoy, con su periodo o fuente." },
  { key: "target", label: "Meta esperada", placeholder: "Valor que se espera alcanzar, no una mejora garantizada." },
  { key: "evidence", label: "Evidencia disponible", placeholder: "Muestras, registros o criterios existentes. Si no hay, indícalo." },
] as const;

type DraftField = "title" | (typeof fieldRows)[number]["key"];
const phases: { id: Phase; label: string }[] = [{ id: "adv", label: "Avance" }, { id: "ret", label: "Retroceso" }];

export default function AnalyzeScreen() {
  const [draft, setDraft] = useState<ProcessDraft>(createEmptyDraft());
  const [ready, setReady] = useState(false);
  const [elementText, setElementText] = useState("");
  const [perspective, setPerspective] = useState<PerspectiveId>("Ind");
  const [mappingPhase, setMappingPhase] = useState<Phase>("adv");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [notice, setNotice] = useState("");
  useEffect(() => { let active = true; loadDraft().then((saved) => { if (active) { if (saved) setDraft(saved); setReady(true); } }); return () => { active = false; }; }, []);
  const diagnosis = useMemo(() => inspectProcess(draft), [draft]);
  const acceptedCount = draft.proposals.filter((proposal) => proposal.status === "accepted").length;
  const reviewedCount = draft.proposals.filter((proposal) => proposal.status !== "pending").length;

  const commit = (next: ProcessDraft, message?: string) => {
    setDraft(next);
    saveDraft(next).then(() => { if (message) setNotice(message); }).catch(() => setNotice("No se pudo guardar el cambio en este dispositivo."));
  };
  const updateField = (key: DraftField, value: string) => { setNotice(""); commit({ ...draft, [key]: value, appliedAt: undefined }); };
  const addMapping = () => {
    const text = elementText.trim();
    if (!text) { setNotice("Escribe un elemento del proceso para agregarlo al mapa."); return; }
    const next: ProcessDraft = { ...draft, appliedAt: undefined, mappings: [...draft.mappings, { id: `map-${Date.now()}`, text, perspective, phase: mappingPhase }] };
    commit(next, `«${text}» se agregó a ${getPerspectiveName(perspective)} · ${mappingPhase === "adv" ? "Avance" : "Retroceso"}.`);
    setElementText("");
  };
  const changeMapping = (id: string, value: PerspectiveId) => commit({ ...draft, appliedAt: undefined, mappings: draft.mappings.map((item) => item.id === id ? { ...item, perspective: value } : item) });
  const changeMappingPhase = (id: string, value: Phase) => commit({ ...draft, appliedAt: undefined, mappings: draft.mappings.map((item) => item.id === id ? { ...item, phase: value } : item) });
  const removeMapping = (id: string) => commit({ ...draft, appliedAt: undefined, mappings: draft.mappings.filter((item) => item.id !== id) }, "Elemento retirado del mapa.");
  const createProposals = () => {
    const proposals = inspectProcess(draft).proposals;
    commit({ ...draft, proposals, appliedAt: undefined }, "Diagnóstico preparado. Cada propuesta conserva su elemento y relación de origen; revísalas una por una.");
  };
  const updateProposal = (id: string, edit: Partial<Proposal>) => commit({ ...draft, proposals: draft.proposals.map((item) => item.id === id ? { ...item, ...edit } : item), appliedAt: undefined });
  const applyAccepted = () => {
    const next = { ...draft, appliedAt: new Date().toISOString() };
    commit(next, `${acceptedCount} cambio(s) aceptado(s) quedaron registrados en este mapa local. No se ejecutó ninguna acción externa.`);
    setConfirmOpen(false);
  };
  const newDraft = () => {
    const fresh = createEmptyDraft();
    commit(fresh, "Se creó un borrador vacío; reemplazó el borrador único almacenado en este dispositivo.");
    setResetOpen(false);
  };

  if (!ready) return <Screen><Text style={ui.muted}>Abriendo tu mapa local…</Text></Screen>;
  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ gap: 17 }}>
        <View style={styles.header}><Eyebrow>ANÁLISIS GUIADO · BORRADOR LOCAL</Eyebrow><Text style={styles.title}>Diseña antes{`\n`}de automatizar.</Text><Text style={styles.subtitle}>Describe lo que ocurre, asigna una perspectiva y fase a cada elemento, y revisa cada relación propuesta.</Text></View>

        <View style={styles.stepBanner}><View style={styles.stepActive}><Text style={styles.stepNumber}>01</Text><Text style={styles.stepLabel}>DESCRIBIR</Text></View><View style={styles.stepConnector} /><View style={styles.stepActive}><Text style={styles.stepNumber}>02</Text><Text style={styles.stepLabel}>MAPEAR</Text></View><View style={styles.stepConnector} /><View style={styles.stepPassive}><Text style={styles.stepNumber}>03</Text><Text style={styles.stepLabel}>REVISAR</Text></View></View>

        <Card style={styles.formCard}><View style={styles.formHead}><View style={styles.formIcon}><Feather name="file-text" size={16} color={C.teal} /></View><View style={{ flex: 1 }}><SectionTitle title="1 · Describe el proceso" detail="Lo que falta queda como una pregunta abierta." /></View></View><Field label="Nombre del proceso" placeholder="Ej. Recepción de solicitudes" value={draft.title} onChangeText={(value) => updateField("title", value)} returnKeyType="next" maxLength={80} />{fieldRows.map((field) => <Field key={field.key} label={field.label} placeholder={field.placeholder} value={draft[field.key]} onChangeText={(value) => updateField(field.key, value)} multiline returnKeyType="default" maxLength={500} />)}</Card>

        <Card style={styles.mapCard}>
          <View style={styles.formHead}><View style={[styles.formIcon, { backgroundColor: C.blue }]}><Feather name="git-pull-request" size={16} color={C.blueInk} /></View><View style={{ flex: 1 }}><SectionTitle title="2 · Mapea elementos" detail="Elige faceta y fase para calcular relaciones formales." /></View><Badge tone="blue">{draft.mappings.length}</Badge></View>
          <Field label="Elemento del proceso" placeholder="Ej. solicitud validada" value={elementText} onChangeText={setElementText} returnKeyType="done" onSubmitEditing={addMapping} />
          <Text style={styles.perspectiveLabel}>¿Qué faceta destaca?</Text>
          <View style={styles.chipGrid}>{PERSPECTIVES.map((item, index) => <Pressable key={item.id} onPress={() => setPerspective(item.id)} accessibilityRole="button" accessibilityState={{ selected: perspective === item.id }} style={[styles.perspectiveChip, perspective === item.id && styles.perspectiveChipSelected, { backgroundColor: perspective === item.id ? [C.tealPale, C.blue, C.lime, C.orange, C.purple][index] : C.paper }]}><Text style={[styles.chipLetter, { color: [C.teal, C.blueInk, C.limeInk, C.orangeInk, C.purpleInk][index] }]}>{item.id}</Text><Text style={styles.chipName}>{item.name}</Text><Text style={styles.chipKind}>{item.kind}</Text></Pressable>)}</View>
          <Text style={styles.perspectiveHint}>{PERSPECTIVES.find((item) => item.id === perspective)?.role}</Text>
          <View style={styles.phasePicker}><Text style={styles.perspectiveLabel}>Fase que describes</Text><View style={styles.phaseChips}>{phases.map((item) => <Pressable key={item.id} onPress={() => setMappingPhase(item.id)} accessibilityRole="button" accessibilityState={{ selected: mappingPhase === item.id }} style={[styles.phaseChoice, mappingPhase === item.id && styles.phaseChoiceActive]}><Text style={[styles.phaseChoiceText, mappingPhase === item.id && styles.phaseChoiceTextActive]}>{item.label}{item.id === "adv" ? " →" : " ←"}</Text></Pressable>)}</View><Text style={ui.small}>Avance y Retroceso son fases explícitas; los vectores Evolución/Involución no se tratan como posiciones.</Text></View>
          <ActionButton title="Agregar al mapa" onPress={addMapping} secondary icon={<Feather name="plus" size={16} color={C.ink} />} />
          {draft.mappings.length ? <View style={styles.mappingList}><Text style={styles.perspectiveLabel}>Elementos del mapa</Text>{draft.mappings.map((item) => <View key={item.id} style={styles.mappingItem}><View style={styles.mappingMain}><View style={styles.mappingBullet}><Feather name="corner-down-right" size={13} color={C.teal} /></View><View style={{ flex: 1 }}><Text style={styles.mappingText}>{item.text}</Text><Text style={styles.mappingAssigned}>{getPerspectiveName(item.perspective)} · {item.phase === "adv" ? "Avance" : "Retroceso"}</Text></View><Pressable onPress={() => removeMapping(item.id)} accessibilityRole="button" accessibilityLabel={`Quitar ${item.text}`} hitSlop={8} style={styles.removeButton}><Feather name="x" size={16} color={C.muted} /></Pressable></View><View style={styles.mappingOptions}>{PERSPECTIVES.map((choice) => <Pressable key={choice.id} onPress={() => changeMapping(item.id, choice.id)} accessibilityRole="button" accessibilityState={{ selected: item.perspective === choice.id }} style={[styles.mappingOption, item.perspective === choice.id && styles.mappingOptionActive]}><Text style={[styles.mappingOptionText, item.perspective === choice.id && { color: C.teal, fontWeight: "800" }]}>{choice.id}</Text></Pressable>)}</View><View style={styles.phaseChips}>{phases.map((choice) => <Pressable key={choice.id} onPress={() => changeMappingPhase(item.id, choice.id)} accessibilityRole="button" accessibilityState={{ selected: item.phase === choice.id }} style={[styles.phaseChoice, styles.phaseChoiceSmall, item.phase === choice.id && styles.phaseChoiceActive]}><Text style={[styles.phaseChoiceText, item.phase === choice.id && styles.phaseChoiceTextActive]}>{choice.label}</Text></Pressable>)}</View></View>)}</View> : <View style={styles.mapEmpty}><Feather name="corner-down-right" size={16} color={C.faint} /><Text style={ui.small}>Agrega al menos dos unidades con faceta y fase para calcular posibles relaciones.</Text></View>}
        </Card>

        <Card style={styles.diagnosisCard}>
          <View style={styles.diagnosisHead}><View style={styles.formIcon}><Feather name="activity" size={16} color={C.teal} /></View><View style={{ flex: 1 }}><SectionTitle title="3 · Diagnóstico IOM" detail="Correspondencias calculadas sobre los metadatos de tu mapa." /></View></View>
          <View style={styles.coverageLine}><Text style={styles.coverageNumber}>{diagnosis.coverage}%</Text><View style={{ flex: 1, gap: 7 }}><Text style={styles.coverageTitle}>cobertura de perspectivas</Text><ProgressLine value={diagnosis.coverage} /></View><Badge tone={diagnosis.coverage >= 60 ? "teal" : "orange"}>{diagnosis.present.length}/5</Badge></View>
          <View style={styles.presenceWrap}>{PERSPECTIVES.map((item) => <Badge key={item.id} tone={diagnosis.present.includes(item.id) ? "teal" : "neutral"}>{diagnosis.present.includes(item.id) ? "✓ " : "○ "}{item.name}</Badge>)}</View>
          {diagnosis.missing.length ? <View style={styles.flagBox}><Feather name="alert-circle" size={15} color={C.orangeInk} /><View style={{ flex: 1 }}><Text style={styles.flagTitle}>Vacíos por explorar</Text><Text style={styles.flagCopy}>{diagnosis.missing.map(getPerspectiveName).join(", ")}. La ausencia no es un error: señala información que aún no se mapeó.</Text></View></View> : <View style={styles.successBox}><Feather name="check-circle" size={15} color="#28695C" /><Text style={styles.successText}>Hay elementos en las cinco perspectivas. Aún requieren contraste con evidencia.</Text></View>}
          <View style={styles.relationPanel}><View style={styles.relationTitleRow}><Feather name="git-merge" size={15} color={C.teal} /><Text style={styles.relationTitle}>Relaciones calculadas</Text><Badge tone="neutral">{diagnosis.relations.length}</Badge></View>{diagnosis.relations.length ? diagnosis.relations.map((relation) => <View key={relation.id} style={styles.detectedRelation}><Badge tone={relation.type === "mirrorOf" ? "blue" : "lime"}>{relation.type}</Badge><View style={{ flex: 1 }}><Text style={styles.detectedRelationTitle}>{relation.sourceText} → {relation.targetText}</Text><Text style={styles.detectedRelationMeta}>{relation.sourcePhase === "adv" ? "Avance" : "Retroceso"} · posición {relation.sourcePosition} → {relation.targetPhase === "adv" ? "Avance" : "Retroceso"} · posición {relation.targetPosition}</Text><Text style={styles.detectedRelationReason}>{relation.explanation} Dominio semántico pendiente de validar.</Text></View></View>) : <Text style={styles.relationEmpty}>No se deriva una arista formal en los mapeos actuales. Se necesita una pareja de posiciones Ind/D/Tot con fases opuestas; para los demás casos se conserva none.</Text>}</View>
          {diagnosis.assumptions.map((item) => <View key={item} style={styles.noteRow}><Feather name="help-circle" size={14} color={C.blueInk} /><Text style={styles.noteText}>{item}</Text></View>)}{diagnosis.conflicts.map((item) => <View key={item} style={styles.noteRow}><Feather name="alert-triangle" size={14} color={C.orangeInk} /><Text style={styles.noteText}>{item}</Text></View>)}
          <Text style={styles.heuristic}>Índice heurístico: {diagnosis.confidence}/100. {diagnosis.confidenceReason}</Text>
          <ActionButton title={draft.proposals.length ? "Actualizar propuestas" : "Preparar propuestas revisables"} onPress={createProposals} icon={<Feather name="zap" size={15} color="#FFFFFF" />} />
        </Card>

        {draft.proposals.length ? <View style={styles.reviewSection}><View style={styles.reviewHeading}><View style={{ flex: 1 }}><Eyebrow>NINGUNA PROPUESTA SE APLICA SOLA</Eyebrow><Text style={styles.reviewTitle}>Revisión previa</Text><Text style={ui.muted}>Cada hipótesis cita su mapeo o arista de origen. Edita, acepta o rechaza cada una.</Text></View><Badge tone="orange">{reviewedCount}/{draft.proposals.length} revisadas</Badge></View>{draft.proposals.map((proposal) => <ProposalReviewCard key={proposal.id} proposal={proposal} onEdit={(value) => updateProposal(proposal.id, { after: value })} onStatus={(status: ProposalStatus) => updateProposal(proposal.id, { status })} />)}<Card style={styles.applyCard}><View style={styles.applyHeader}><View style={styles.applyIcon}><Feather name="shield" size={16} color={C.teal} /></View><View style={{ flex: 1 }}><Text style={styles.applyTitle}>Resumen de decisión</Text><Text style={styles.applyText}>{acceptedCount} aceptada(s) · {draft.proposals.length - acceptedCount} sin aprobación</Text></View></View>{draft.appliedAt ? <View style={styles.successBox}><Feather name="check-circle" size={15} color="#28695C" /><Text style={styles.successText}>Decisión confirmada y guardada en este dispositivo. No se ejecutaron cambios externos.</Text></View> : null}<ActionButton title="Confirmar cambios aceptados" onPress={() => setConfirmOpen(true)} disabled={acceptedCount === 0} icon={<Feather name="check" size={15} color="#FFFFFF" />} /><Text style={styles.applyFoot}>Solo registra el cierre de revisión de este mapa. No conecta ni modifica sistemas externos.</Text></Card></View> : null}

        <Card style={styles.localNote}><View style={styles.noteIcon}><Feather name="lock" size={15} color="#28695C" /></View><Text style={styles.localCopy}>Borrador y decisiones guardados localmente. Las sugerencias sobre tu proceso son hipótesis; el aprendizaje de referencia es sintético.</Text></Card>
        {notice ? <View accessibilityLiveRegion="polite" style={styles.notice}><Feather name="info" size={14} color={C.teal} /><Text style={styles.noticeText}>{notice}</Text></View> : null}
        <ActionButton title="Nuevo borrador" onPress={() => setResetOpen(true)} secondary icon={<Feather name="file-plus" size={15} color={C.ink} />} />
        <Text style={styles.resetWarning}>La app conserva un borrador activo por dispositivo; crear otro reemplaza el actual tras confirmar.</Text>
      </KeyboardAvoidingView>

      <Modal transparent visible={confirmOpen} animationType="fade" onRequestClose={() => setConfirmOpen(false)}>
        <View style={styles.modalBackdrop}><View style={styles.modalCard} accessibilityViewIsModal><View style={styles.modalIcon}><Feather name="shield" size={21} color={C.teal} /></View><Eyebrow>CONFIRMACIÓN EXPLÍCITA</Eyebrow><Text style={styles.modalTitle}>¿Registrar los cambios aceptados?</Text><Text style={styles.modalBody}>Se marcarán {acceptedCount} propuesta(s) como confirmadas en «{draft.title || "Proceso sin nombre"}». Esto no ejecutará una automatización ni escribirá en un sistema externo.</Text><ActionButton title="Confirmar y guardar" onPress={applyAccepted} /><Pressable onPress={() => setConfirmOpen(false)} accessibilityRole="button" style={styles.cancelButton}><Text style={styles.cancelText}>Volver a revisar</Text></Pressable></View></View>
      </Modal>
      <Modal transparent visible={resetOpen} animationType="fade" onRequestClose={() => setResetOpen(false)}>
        <View style={styles.modalBackdrop}><View style={styles.modalCard} accessibilityViewIsModal><View style={[styles.modalIcon, { backgroundColor: C.orange }]}><Feather name="alert-triangle" size={21} color={C.orangeInk} /></View><Eyebrow>REEMPLAZAR BORRADOR LOCAL</Eyebrow><Text style={styles.modalTitle}>¿Crear un mapa nuevo?</Text><Text style={styles.modalBody}>IOM Flow guarda un solo borrador activo. Esta acción reemplazará «{draft.title || "Proceso sin nombre"}» y sus decisiones guardadas en el dispositivo.</Text><ActionButton title="Reemplazar y crear nuevo" onPress={newDraft} /><Pressable onPress={() => setResetOpen(false)} accessibilityRole="button" style={styles.cancelButton}><Text style={styles.cancelText}>Conservar borrador actual</Text></Pressable></View></View>
      </Modal>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 8, paddingTop: 7 }, title: { color: C.ink, fontSize: 35, lineHeight: 38, letterSpacing: -1, fontWeight: "700" }, subtitle: { color: C.muted, fontSize: 14, lineHeight: 21 },
  stepBanner: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 12, borderRadius: 17, backgroundColor: "#EDF1E9" }, stepActive: { alignItems: "center", gap: 4 }, stepPassive: { alignItems: "center", opacity: 0.6, gap: 4 }, stepNumber: { color: C.teal, fontSize: 12, fontWeight: "800" }, stepLabel: { color: C.muted, fontSize: 9, fontWeight: "800", letterSpacing: 0.6 }, stepConnector: { height: 1, flex: 1, backgroundColor: "#CCD8CF", marginHorizontal: 9, marginBottom: 12 },
  formCard: { padding: 15 }, formHead: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 1 }, formIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center" }, mapCard: { padding: 15 }, mapEmpty: { flexDirection: "row", gap: 8, alignItems: "center", padding: 11, borderRadius: 13, backgroundColor: C.canvas },
  perspectiveLabel: { color: C.ink, fontWeight: "700", fontSize: 12, marginTop: 4 }, chipGrid: { flexDirection: "row", flexWrap: "wrap", gap: 7 }, perspectiveChip: { width: "31.5%", minHeight: 82, borderRadius: 13, borderWidth: 1, borderColor: C.line, alignItems: "center", justifyContent: "center", gap: 3, padding: 6 }, perspectiveChipSelected: { borderColor: C.teal, borderWidth: 1.5 }, chipLetter: { fontSize: 13, fontWeight: "800" }, chipName: { fontSize: 10, color: C.ink, fontWeight: "700", textAlign: "center" }, chipKind: { fontSize: 9, color: C.muted }, perspectiveHint: { color: C.muted, fontSize: 11, lineHeight: 16 }, phasePicker: { gap: 7, padding: 10, backgroundColor: C.canvas, borderRadius: 13 }, phaseChips: { flexDirection: "row", flexWrap: "wrap", gap: 6 }, phaseChoice: { flex: 1, minHeight: 38, minWidth: 90, alignItems: "center", justifyContent: "center", borderRadius: 10, backgroundColor: C.paper, borderWidth: 1, borderColor: C.line }, phaseChoiceSmall: { minHeight: 34 }, phaseChoiceActive: { backgroundColor: C.tealPale, borderColor: "#A9D6C9" }, phaseChoiceText: { color: C.muted, fontSize: 11, fontWeight: "600" }, phaseChoiceTextActive: { color: C.teal, fontWeight: "800" },
  mappingList: { gap: 9, paddingTop: 5 }, mappingItem: { backgroundColor: C.canvas, padding: 11, borderRadius: 14, gap: 9 }, mappingMain: { flexDirection: "row", alignItems: "center", gap: 8 }, mappingBullet: { width: 27, height: 27, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: C.tealPale }, mappingText: { color: C.ink, fontSize: 13, fontWeight: "700" }, mappingAssigned: { color: C.muted, fontSize: 10, marginTop: 2 }, removeButton: { width: 34, height: 34, alignItems: "center", justifyContent: "center", borderRadius: 10, backgroundColor: C.paper }, mappingOptions: { flexDirection: "row", gap: 6, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8 }, mappingOption: { minWidth: 38, minHeight: 32, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: C.paper }, mappingOptionActive: { backgroundColor: C.tealPale }, mappingOptionText: { color: C.muted, fontSize: 11, fontWeight: "600" },
  diagnosisCard: { padding: 15 }, diagnosisHead: { flexDirection: "row", alignItems: "center", gap: 10 }, coverageLine: { flexDirection: "row", alignItems: "center", gap: 10 }, coverageNumber: { color: C.ink, fontSize: 30, fontWeight: "700", letterSpacing: -1 }, coverageTitle: { color: C.muted, fontSize: 11 }, presenceWrap: { flexDirection: "row", flexWrap: "wrap", gap: 6 }, flagBox: { flexDirection: "row", gap: 8, padding: 11, backgroundColor: C.orange, borderRadius: 13 }, flagTitle: { color: C.orangeInk, fontSize: 12, fontWeight: "700" }, flagCopy: { color: C.orangeInk, fontSize: 11, lineHeight: 17, marginTop: 3 }, successBox: { flexDirection: "row", alignItems: "flex-start", gap: 7, padding: 10, backgroundColor: C.tealPale, borderRadius: 12 }, successText: { flex: 1, color: "#28695C", fontSize: 11, lineHeight: 17, fontWeight: "600" }, noteRow: { flexDirection: "row", alignItems: "flex-start", gap: 7 }, noteText: { color: C.muted, fontSize: 11, lineHeight: 16, flex: 1 }, heuristic: { color: C.muted, fontSize: 10, lineHeight: 16, paddingTop: 4 },
  relationPanel: { gap: 9, padding: 11, borderRadius: 14, backgroundColor: C.canvas }, relationTitleRow: { flexDirection: "row", alignItems: "center", gap: 7 }, relationTitle: { flex: 1, color: C.ink, fontSize: 12, fontWeight: "700" }, detectedRelation: { flexDirection: "row", alignItems: "flex-start", gap: 8, paddingTop: 7, borderTopWidth: 1, borderTopColor: C.line }, detectedRelationTitle: { color: C.ink, fontSize: 12, fontWeight: "700" }, detectedRelationMeta: { color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 2 }, detectedRelationReason: { color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 3 }, relationEmpty: { color: C.muted, fontSize: 11, lineHeight: 17 },
  reviewSection: { gap: 12 }, reviewHeading: { flexDirection: "row", alignItems: "center", gap: 8 }, reviewTitle: { color: C.ink, fontSize: 21, fontWeight: "700", marginVertical: 2 }, applyCard: { backgroundColor: "#F0F3EB", borderColor: "#D9E2D6" }, applyHeader: { flexDirection: "row", alignItems: "center", gap: 9 }, applyIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center" }, applyTitle: { color: C.ink, fontSize: 14, fontWeight: "700" }, applyText: { color: C.muted, fontSize: 11, marginTop: 3 }, applyFoot: { color: C.muted, fontSize: 10, lineHeight: 15 },
  localNote: { flexDirection: "row", gap: 9, alignItems: "flex-start", backgroundColor: "#ECF2E7", borderColor: "#D7E4D1", padding: 13 }, noteIcon: { width: 27, height: 27, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: "#DCE9D5" }, localCopy: { flex: 1, color: C.muted, fontSize: 11, lineHeight: 17 }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 11, borderRadius: 13, backgroundColor: C.tealPale }, noticeText: { flex: 1, color: C.ink, fontSize: 11, lineHeight: 17 }, resetWarning: { color: C.faint, textAlign: "center", fontSize: 10, lineHeight: 15 },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(10,28,26,0.58)", justifyContent: "center", padding: 22 }, modalCard: { borderRadius: 22, backgroundColor: C.canvas, padding: 21, gap: 12 }, modalIcon: { width: 43, height: 43, borderRadius: 15, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center" }, modalTitle: { color: C.ink, fontSize: 21, fontWeight: "700", lineHeight: 26 }, modalBody: { color: C.muted, fontSize: 13, lineHeight: 20 }, cancelButton: { minHeight: 44, alignItems: "center", justifyContent: "center" }, cancelText: { color: C.ink, fontSize: 13, fontWeight: "700" },
});
