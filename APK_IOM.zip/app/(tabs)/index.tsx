import { Feather } from "@expo/vector-icons";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { ActionButton, Badge, C, Card, Eyebrow, ProgressLine, Screen, SectionTitle, ui } from "@/components/iom-ui";
import { OPERATION_STEPS, TRIADS } from "@/lib/iom-spec";
import { loadDraft, type ProcessDraft } from "@/lib/storage";

export default function HomeScreen() {
  const router = useRouter();
  const [draft, setDraft] = useState<ProcessDraft | null>(null);
  useFocusEffect(useCallback(() => { let active = true; loadDraft().then((value) => { if (active) setDraft(value); }); return () => { active = false; }; }, []));
  const mappedCount = draft?.mappings.filter((item) => item.text.trim()).length ?? 0;

  return (
    <Screen>
      <View style={styles.topline}><View style={styles.brandMark}><Feather name="git-merge" size={17} color={C.dark} /></View><View style={{ flex: 1 }}><Eyebrow>IOM FLOW · ESPACIO DE TRABAJO</Eyebrow><Text style={styles.brandTitle}>Mapa vivo de procesos</Text></View><View style={styles.localChip}><View style={styles.localDot} /><Text style={styles.localText}>Local</Text></View></View>
      <Card dark style={styles.hero}>
        <View style={styles.heroTop}><Badge tone="teal">MARCO IOM · 1.9</Badge><Feather name="arrow-up-right" size={20} color="#B9E7DC" /></View>
        <Text style={styles.heroTitle}>De la señal{`\n`}al cambio, con{`\n`}trazabilidad.</Text>
        <Text style={styles.heroCopy}>Estructura procesos como unidades informativas. Revisa cada propuesta antes de automatizarla.</Text>
        <ActionButton title={draft?.title ? "Continuar análisis" : "Mapear un proceso"} onPress={() => router.push("/analyze")} icon={<Feather name="arrow-right" size={17} color="#FFFFFF" />} />
        <View style={styles.heroFooter}><Feather name="shield" size={14} color="#AACBC3" /><Text style={styles.heroFootText}>Sin aplicar cambios automáticamente</Text></View>
        <View pointerEvents="none" style={styles.heroOrbOuter}><View style={styles.heroOrbInner} /></View>
      </Card>

      <View style={styles.statRow}><Card style={styles.statCard}><Text style={styles.statNumber}>{TRIADS.length.toString().padStart(2, "0")}</Text><Text style={styles.statLabel}>tríadas IOM</Text><Text style={styles.statSub}>marco de referencia</Text></Card><Card style={styles.statCard}><Text style={styles.statNumber}>05</Text><Text style={styles.statLabel}>perspectivas</Text><Text style={styles.statSub}>para mapear</Text></Card><Card style={styles.statCard}><Text style={styles.statNumber}>{mappedCount.toString().padStart(2, "0")}</Text><Text style={styles.statLabel}>elementos</Text><Text style={styles.statSub}>en tu proceso</Text></Card></View>

      <View style={styles.sectionHead}><SectionTitle title="Cadena operativa" detail="Una ruta de distinción a unidad." /><Badge tone="neutral">6 ETAPAS</Badge></View>
      <Card style={styles.stepsCard}>{OPERATION_STEPS.map((step, index) => <View key={step.title} style={styles.stepRow}><View style={styles.stepRail}><View style={[styles.stepNode, index === OPERATION_STEPS.length - 1 && styles.lastNode]}><Text style={[styles.stepMark, index === OPERATION_STEPS.length - 1 && { color: C.paper }]}>{step.mark}</Text></View>{index < OPERATION_STEPS.length - 1 && <View style={styles.stepLine} />}</View><View style={styles.stepContent}><Text style={styles.stepTitle}>{step.title}</Text><Text style={styles.stepDetail}>{step.detail}</Text></View>{index < OPERATION_STEPS.length - 1 ? <Feather name="arrow-down" size={13} color="#AAB6AF" style={{ marginTop: 5 }} /> : null}</View>)}</Card>

      <SectionTitle title="Tu mapa de proceso" detail="El diagnóstico se guarda en este dispositivo." />
      {draft?.title ? <Card style={styles.processCard}><View style={styles.processHeader}><View style={styles.processIcon}><Feather name="git-pull-request" size={17} color={C.teal} /></View><View style={{ flex: 1 }}><Text style={styles.processName} numberOfLines={1}>{draft.title}</Text><Text style={ui.small}>{mappedCount} elemento(s) mapeado(s)</Text></View><Feather name="chevron-right" size={18} color={C.faint} /></View><ProgressLine value={Math.min(100, mappedCount * 20)} /><Pressable onPress={() => router.push("/analyze")} accessibilityRole="button" style={styles.continueLink}><Text style={styles.linkText}>Abrir análisis</Text><Feather name="arrow-right" size={14} color={C.teal} /></Pressable></Card> : <Card style={styles.emptyCard}><View style={styles.emptyIcon}><Feather name="layers" size={19} color={C.teal} /></View><Text style={styles.emptyTitle}>Empieza por lo que sucede hoy.</Text><Text style={styles.emptyBody}>Describe entradas, personas, límites y resultados. IOM te ayuda a ver conexiones y vacíos.</Text><ActionButton title="Crear primer mapa" onPress={() => router.push("/analyze")} secondary /></Card>}

      <Card style={styles.noteCard}><View style={styles.noteIcon}><Feather name="info" size={16} color="#3D6E66" /></View><View style={{ flex: 1 }}><Text style={styles.noteTitle}>Reglas no son aprendizaje generalizado</Text><Text style={styles.noteCopy}>El corpus IOM incluido es sintético. Las métricas del módulo de referencia demuestran recuperación interna, no mejora de procesos reales.</Text></View></Card>
      <Text style={styles.footer}>IOM Flow · Herramienta de exploración y revisión humana</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topline: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 2 }, brandMark: { width: 39, height: 39, borderRadius: 14, backgroundColor: C.lime, alignItems: "center", justifyContent: "center" }, brandTitle: { color: C.ink, fontSize: 15, fontWeight: "700", marginTop: 3 }, localChip: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, paddingVertical: 7, backgroundColor: C.paper, borderColor: C.line, borderWidth: 1, borderRadius: 99 }, localDot: { width: 6, height: 6, backgroundColor: C.teal, borderRadius: 9 }, localText: { fontSize: 10, color: C.muted, fontWeight: "700" },
  hero: { padding: 22, overflow: "hidden", minHeight: 315 }, heroTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, heroTitle: { color: "#F8FAF4", fontSize: 34, lineHeight: 38, letterSpacing: -1.1, fontWeight: "700", marginTop: 16 }, heroCopy: { color: "#C1D0CB", fontSize: 14, lineHeight: 21, maxWidth: 270, marginBottom: 4 }, heroFooter: { flexDirection: "row", gap: 7, alignItems: "center", marginTop: 2 }, heroFootText: { color: "#AACBC3", fontSize: 11 }, heroOrbOuter: { position: "absolute", right: -31, top: 89, width: 112, height: 112, borderRadius: 70, borderWidth: 1, borderColor: "rgba(38,183,164,0.25)", alignItems: "center", justifyContent: "center" }, heroOrbInner: { width: 63, height: 63, borderRadius: 40, borderWidth: 1, borderColor: "rgba(229,240,190,0.5)" },
  statRow: { flexDirection: "row", gap: 8 }, statCard: { flex: 1, paddingHorizontal: 12, paddingVertical: 14, borderRadius: 18, gap: 1 }, statNumber: { color: C.ink, fontSize: 25, fontWeight: "700", letterSpacing: -0.5 }, statLabel: { color: C.ink, fontSize: 11, fontWeight: "700" }, statSub: { color: C.muted, fontSize: 9, marginTop: 3 }, sectionHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  stepsCard: { gap: 0, paddingVertical: 8 }, stepRow: { minHeight: 56, flexDirection: "row", alignItems: "flex-start", gap: 12 }, stepRail: { width: 27, alignItems: "center" }, stepNode: { width: 25, height: 25, borderRadius: 9, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center", zIndex: 1 }, lastNode: { backgroundColor: C.dark }, stepMark: { color: C.teal, fontSize: 13, fontWeight: "700" }, stepLine: { position: "absolute", top: 25, bottom: -5, width: 1, backgroundColor: "#CDE0D8" }, stepContent: { flex: 1, paddingBottom: 12 }, stepTitle: { color: C.ink, fontSize: 13, fontWeight: "700" }, stepDetail: { color: C.muted, fontSize: 11, lineHeight: 17, marginTop: 2 },
  processCard: { gap: 13 }, processHeader: { flexDirection: "row", alignItems: "center", gap: 11 }, processIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center" }, processName: { color: C.ink, fontSize: 15, fontWeight: "700" }, continueLink: { flexDirection: "row", alignItems: "center", gap: 7, alignSelf: "flex-start", minHeight: 34 }, linkText: { color: C.teal, fontWeight: "700", fontSize: 13 }, emptyCard: { alignItems: "flex-start" }, emptyIcon: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: C.tealPale }, emptyTitle: { fontSize: 16, fontWeight: "700", color: C.ink }, emptyBody: { fontSize: 13, color: C.muted, lineHeight: 20 },
  noteCard: { flexDirection: "row", alignItems: "flex-start", backgroundColor: "#ECF2E7", borderColor: "#D7E4D1", padding: 15 }, noteIcon: { width: 27, height: 27, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: "#DCE9D5" }, noteTitle: { color: C.ink, fontSize: 13, fontWeight: "700" }, noteCopy: { color: C.muted, fontSize: 12, lineHeight: 18, marginTop: 4 }, footer: { textAlign: "center", color: C.faint, fontSize: 10, marginVertical: 4 },
});
