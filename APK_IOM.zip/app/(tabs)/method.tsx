import { Feather } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { ActionButton, Badge, C, Card, Eyebrow, ProgressLine, Screen, SectionTitle, ui } from "@/components/iom-ui";
import { loadTrainingReport, saveTrainingReport, type TrainingReport } from "@/lib/storage";
import { trainReferenceModel } from "@/lib/iom-training";

export default function MethodScreen() {
  const [report, setReport] = useState<TrainingReport | null>(null);
  const [running, setRunning] = useState(false);
  const [notice, setNotice] = useState("");
  useEffect(() => { let active = true; loadTrainingReport().then((value) => { if (active) setReport(value); }); return () => { active = false; }; }, []);
  const runTraining = () => {
    setRunning(true);
    setNotice("");
    requestAnimationFrame(() => {
      const next = trainReferenceModel();
      saveTrainingReport(next).then(() => {
        setReport(next);
        setRunning(false);
        setNotice("Entrenamiento de referencia completado y guardado en este dispositivo.");
      }).catch(() => {
        setReport(next);
        setRunning(false);
        setNotice("El cálculo terminó, pero no se pudo guardar el reporte local.");
      });
    });
  };
  const percent = report ? Math.round(report.accuracy * 100) : 0;
  return (
    <Screen>
      <View style={styles.header}><Eyebrow>MÉTODO · PROCEDENCIA · EVIDENCIA</Eyebrow><Text style={styles.title}>Qué puede{`\n`}afirmar el modelo</Text><Text style={styles.subtitle}>Entrena el clasificador interno de referencia y distingue su recuperación de reglas de la validación de un proceso real.</Text></View>

      <Card dark style={styles.modelCard}><View style={styles.modelHeader}><View style={styles.modelIcon}><Feather name="cpu" size={19} color={C.lime} /></View><View style={{ flex: 1 }}><Eyebrow light>MODELO DE REFERENCIA</Eyebrow><Text style={styles.modelTitle}>Recuperación de reglas IOM</Text></View><Badge tone="orange">SINTÉTICO</Badge></View><Text style={styles.modelCopy}>Clasificador k-NN, ajustado localmente sobre nodos IOM. Deja una tríada fuera en cada partición y compara la etiqueta predicha con la etiqueta formal.</Text><View style={styles.modelFacts}><View style={styles.modelFact}><Text style={styles.modelFactValue}>78</Text><Text style={styles.modelFactLabel}>ejemplos</Text></View><View style={styles.factDivider} /><View style={styles.modelFact}><Text style={styles.modelFactValue}>13</Text><Text style={styles.modelFactLabel}>particiones</Text></View><View style={styles.factDivider} /><View style={styles.modelFact}><Text style={styles.modelFactValue}>k=1</Text><Text style={styles.modelFactLabel}>vecino más cercano</Text></View></View><ActionButton title={running ? "Entrenando…" : report ? "Volver a entrenar" : "Entrenar modelo de referencia"} onPress={runTraining} disabled={running} icon={<Feather name="play" size={15} color="#FFFFFF" />} /></Card>

      {notice ? <View accessibilityLiveRegion="polite" style={styles.notice}><Feather name="check-circle" size={15} color="#28695C" /><Text style={styles.noticeText}>{notice}</Text></View> : null}
      {report ? <Card style={styles.resultCard}><View style={styles.resultHeader}><View><Eyebrow>RESULTADO DEL CORPUS</Eyebrow><Text style={styles.resultTitle}>Exactitud por tríada</Text></View><Badge tone="orange">Diagnóstico circular</Badge></View><View style={styles.metricLine}><Text style={styles.metricValue}>{percent}%</Text><Text style={styles.metricCaption}>de etiquetas recuperadas</Text></View><ProgressLine value={percent} /><Text style={styles.resultCopy}>{report.sampleCount} nodos · {report.foldCount} particiones · {report.algorithm}</Text><Text style={styles.resultDate}>Último cálculo: {new Date(report.trainedAt).toLocaleString("es-MX", { dateStyle: "medium", timeStyle: "short" })}</Text></Card> : <Card style={styles.emptyState}><Feather name="bar-chart-2" size={20} color={C.teal} /><Text style={styles.emptyTitle}>Aún no has ejecutado el entrenamiento.</Text><Text style={ui.muted}>El cálculo ocurre en este dispositivo, con el corpus de referencia adjunto.</Text></Card>}

      <Card style={styles.limitCard}><View style={styles.limitHead}><View style={styles.limitIcon}><Feather name="alert-triangle" size={16} color={C.orangeInk} /></View><View style={{ flex: 1 }}><Eyebrow>LECTURA RESPONSABLE</Eyebrow><Text style={styles.limitTitle}>Un 100% no significa generalización.</Text></View></View><Text style={styles.limitBody}>El conjunto repite las combinaciones de fase y posición en cada tríada. La etiqueta objetivo ya se deriva de la posición; una tríada fuera del entrenamiento aún tiene los mismos patrones que las tríadas incluidas. El modelo recupera esa estructura sintética, no aprende a optimizar procesos del mundo real.</Text><View style={styles.cautionRule}><Text style={styles.cautionLabel}>NO es</Text><Text style={styles.cautionText}>validación semántica externa, causalidad ni mejora medida.</Text></View><View style={styles.cautionRule}><Text style={styles.cautionLabel}>PARA afirmar aprendizaje empírico</Text><Text style={styles.cautionText}>harían falta datos de proceso, procedencia, etiquetas, separación de evaluación y resultados documentados.</Text></View></Card>

      <SectionTitle title="Capas de verificación" detail="Cada capa responde una pregunta distinta." />
      <Card style={styles.layerCard}><View style={styles.layerMark}><Text style={styles.layerNumber}>01</Text></View><View style={{ flex: 1, gap: 4 }}><View style={styles.layerHeading}><Text style={styles.layerTitle}>Especificación canónica</Text><Badge tone="teal">Base formal</Badge></View><Text style={ui.muted}>`iom_spec.json`, CSV y ontología describen el sistema IOM y sus relaciones.</Text></View></Card>
      <Card style={styles.layerCard}><View style={[styles.layerMark, { backgroundColor: C.blue }]}><Text style={[styles.layerNumber, { color: C.blueInk }]}>02</Text></View><View style={{ flex: 1, gap: 4 }}><View style={styles.layerHeading}><Text style={styles.layerTitle}>Lean + SHACL</Text><Badge tone="blue">Verificación formal</Badge></View><Text style={ui.muted}>El repositorio ofrece comprobaciones formales. Esta app las documenta, pero no compila Lean ni ejecuta SHACL.</Text></View></Card>
      <Card style={styles.layerCard}><View style={[styles.layerMark, { backgroundColor: C.lime }]}><Text style={[styles.layerNumber, { color: C.limeInk }]}>03</Text></View><View style={{ flex: 1, gap: 4 }}><View style={styles.layerHeading}><Text style={styles.layerTitle}>Diagnóstico sintético</Text><Badge tone="orange">Recuperación</Badge></View><Text style={ui.muted}>Recupera reglas ya presentes en las características del corpus; es una prueba de estructura interna.</Text></View></Card>
      <Card style={styles.layerCard}><View style={[styles.layerMark, { backgroundColor: C.purple }]}><Text style={[styles.layerNumber, { color: C.purpleInk }]}>04</Text></View><View style={{ flex: 1, gap: 4 }}><View style={styles.layerHeading}><Text style={styles.layerTitle}>Encuentro con un dominio</Text><Badge tone="purple">Hipótesis</Badge></View><Text style={ui.muted}>Un mapeo de dominio externo es una propuesta a contrastar; no certifica verdad universal ni eficacia del proceso.</Text></View></Card>

      <Card style={styles.sourceCard}><View style={styles.sourceHead}><Feather name="book-open" size={16} color={C.teal} /><Text style={styles.sourceTitle}>Procedencia de esta demo</Text></View><Text style={styles.sourceCopy}>Basado en el repositorio IOM adjunto: especificación 1.9.0, cinco perspectivas, 13 tríadas, 78 nodos y sus auditorías metodológicas. El estado «aprendizaje entrenado» se reserva para un modelo con datos y evaluación documentados; este resultado permanece etiquetado como diagnóstico sintético.</Text></Card>
      <Card style={styles.taxonomyCard}><View style={styles.sourceHead}><Feather name="tag" size={16} color={C.teal} /><Text style={styles.sourceTitle}>Cómo leer el estado de evidencia</Text></View>
        <View style={styles.taxonomyRow}><Badge tone="blue">Demostración de reglas</Badge><Text style={styles.taxonomyText}>Solo una verificación formal la respalda. Esta app muestra la fuente, pero no ejecuta Lean ni SHACL.</Text></View>
        <View style={styles.taxonomyRow}><Badge tone="orange">Hipótesis</Badge><Text style={styles.taxonomyText}>Etiqueta cada sugerencia sobre el proceso; la persona debe revisarla y contrastarla.</Text></View>
        <View style={styles.taxonomyRow}><Badge tone="purple">Evidencia de encuentro</Badge><Text style={styles.taxonomyText}>La app no certifica validación externa ni sustituye los datos de un dominio.</Text></View>
        <View style={styles.taxonomyRow}><Badge tone="teal">Aprendizaje entrenado</Badge><Text style={styles.taxonomyText}>Se reserva para datos, entrenamiento y evaluación documentados; no describe el resultado sintético.</Text></View>
      </Card>
      <Text style={styles.footer}>El cálculo mide recuperación de reglas del corpus, no calidad de una automatización.</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 8, paddingTop: 7 }, title: { color: C.ink, fontSize: 35, lineHeight: 38, letterSpacing: -1, fontWeight: "700" }, subtitle: { color: C.muted, fontSize: 14, lineHeight: 21 },
  modelCard: { padding: 19 }, modelHeader: { flexDirection: "row", alignItems: "center", gap: 10 }, modelIcon: { width: 39, height: 39, borderRadius: 14, backgroundColor: "#204942", alignItems: "center", justifyContent: "center" }, modelTitle: { color: "#FFFFFF", fontSize: 15, fontWeight: "700", marginTop: 3 }, modelCopy: { color: "#C1D0CB", fontSize: 12, lineHeight: 19 }, modelFacts: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 12, borderTopWidth: 1, borderBottomWidth: 1, borderColor: "#35514C" }, modelFact: { flex: 1, alignItems: "center", gap: 3 }, modelFactValue: { color: C.lime, fontSize: 20, fontWeight: "800" }, modelFactLabel: { color: "#AFC6C0", fontSize: 10, textAlign: "center" }, factDivider: { width: 1, height: 27, backgroundColor: "#35514C" },
  notice: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 13, paddingVertical: 11, borderRadius: 13, backgroundColor: C.tealPale }, noticeText: { flex: 1, color: "#28695C", fontSize: 12, lineHeight: 18, fontWeight: "600" }, resultCard: { gap: 11 }, resultHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }, resultTitle: { color: C.ink, fontSize: 16, fontWeight: "700", marginTop: 3 }, metricLine: { flexDirection: "row", alignItems: "baseline", gap: 8 }, metricValue: { color: C.ink, fontSize: 39, fontWeight: "700", letterSpacing: -1.5 }, metricCaption: { color: C.muted, fontSize: 13 }, resultCopy: { color: C.ink, fontSize: 12, fontWeight: "600" }, resultDate: { color: C.faint, fontSize: 11 }, emptyState: { alignItems: "flex-start" }, emptyTitle: { color: C.ink, fontWeight: "700", fontSize: 15 },
  limitCard: { backgroundColor: "#FFF9F1", borderColor: "#F0DFCA" }, limitHead: { flexDirection: "row", alignItems: "center", gap: 10 }, limitIcon: { width: 35, height: 35, backgroundColor: C.orange, borderRadius: 12, justifyContent: "center", alignItems: "center" }, limitTitle: { color: C.ink, fontSize: 15, fontWeight: "700", marginTop: 3 }, limitBody: { color: C.ink, fontSize: 12, lineHeight: 19 }, cautionRule: { borderLeftWidth: 2, borderLeftColor: "#D8A96D", paddingLeft: 10, gap: 3 }, cautionLabel: { color: C.orangeInk, fontSize: 10, fontWeight: "800", letterSpacing: 0.5 }, cautionText: { color: C.muted, fontSize: 11, lineHeight: 17 },
  layerCard: { flexDirection: "row", gap: 11, padding: 14 }, layerMark: { width: 34, height: 34, borderRadius: 11, backgroundColor: C.tealPale, alignItems: "center", justifyContent: "center" }, layerNumber: { color: C.teal, fontSize: 12, fontWeight: "800" }, layerHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 5 }, layerTitle: { color: C.ink, fontSize: 13, fontWeight: "700", flexShrink: 1 }, sourceCard: { backgroundColor: "#EDF3EE", borderColor: "#D8E5DD" }, sourceHead: { flexDirection: "row", alignItems: "center", gap: 8 }, sourceTitle: { color: C.ink, fontSize: 13, fontWeight: "700" }, sourceCopy: { color: C.muted, fontSize: 12, lineHeight: 19 }, taxonomyCard: { backgroundColor: "#F0F3EB", borderColor: "#D9E2D6" }, taxonomyRow: { flexDirection: "row", alignItems: "flex-start", gap: 9 }, taxonomyText: { flex: 1, color: C.muted, fontSize: 11, lineHeight: 17, paddingTop: 4 }, footer: { textAlign: "center", color: C.faint, fontSize: 10, marginVertical: 3 },
});
