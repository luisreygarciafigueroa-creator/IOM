import { formalRelation, getPerspectiveName, PERSPECTIVES, type Phase, type PerspectiveId } from "./iom-spec";
import type { ProcessDraft, Proposal } from "./storage";

export type ProcessRelation = {
  id: string;
  type: "mirrorOf" | "creates";
  sourceId: string;
  sourceText: string;
  sourcePerspective: PerspectiveId;
  sourcePhase: Phase;
  sourcePosition: number;
  targetId: string;
  targetText: string;
  targetPerspective: PerspectiveId;
  targetPhase: Phase;
  targetPosition: number;
  explanation: string;
};

const positionalIndex: Partial<Record<PerspectiveId, number>> = { Ind: 0, D: 1, Tot: 2 };
const phaseLabel = (phase: Phase) => phase === "adv" ? "Avance" : "Retroceso";

function findProcessRelations(mappings: ProcessDraft["mappings"]): ProcessRelation[] {
  const relations: ProcessRelation[] = [];
  for (let i = 0; i < mappings.length; i += 1) {
    for (let j = i + 1; j < mappings.length; j += 1) {
      const source = mappings[i];
      const target = mappings[j];
      const sourcePosition = positionalIndex[source.perspective];
      const targetPosition = positionalIndex[target.perspective];
      // Evol/Invol are directional vectors, not one of the three positions used by these edge rules.
      if (sourcePosition === undefined || targetPosition === undefined) continue;
      const type = formalRelation(
        { phase: source.phase ?? "adv", position: sourcePosition },
        { phase: target.phase ?? "adv", position: targetPosition },
      );
      if (type === "none") continue;
      relations.push({
        id: `relation-${source.id}-${target.id}`,
        type,
        sourceId: source.id,
        sourceText: source.text,
        sourcePerspective: source.perspective,
        sourcePhase: source.phase ?? "adv",
        sourcePosition,
        targetId: target.id,
        targetText: target.text,
        targetPerspective: target.perspective,
        targetPhase: target.phase ?? "adv",
        targetPosition,
        explanation: type === "mirrorOf"
          ? "Fases opuestas y posición objetivo igual a 2 − posición origen."
          : "Fases opuestas y transición entre una posición lateral y la central.",
      });
    }
  }
  return relations;
}

export function inspectProcess(draft: ProcessDraft): {
  mappedCount: number;
  coverage: number;
  present: PerspectiveId[];
  missing: PerspectiveId[];
  assumptions: string[];
  conflicts: string[];
  relations: ProcessRelation[];
  proposals: Proposal[];
  confidence: number;
  confidenceReason: string;
} {
  const mapped = draft.mappings.filter((item) => item.text.trim());
  const present = PERSPECTIVES.filter((perspective) => mapped.some((item) => item.perspective === perspective.id)).map((item) => item.id);
  const missing = PERSPECTIVES.filter((perspective) => !present.includes(perspective.id)).map((item) => item.id);
  const coverage = Math.round((present.length / PERSPECTIVES.length) * 100);
  const relations = findProcessRelations(mapped);
  const assumptions: string[] = [];
  const conflicts: string[] = [];
  if (!draft.evidence.trim()) assumptions.push("No se describió evidencia o datos disponibles; las sugerencias son hipótesis de diseño.");
  if (!draft.actors.trim()) assumptions.push("Falta identificar quién inicia o responde por el proceso.");
  if (!draft.expectedOutput.trim()) assumptions.push("El resultado esperado no está definido, por lo que no hay criterio de éxito evaluable.");
  if (!draft.successMetric.trim()) assumptions.push("No hay una métrica de éxito; todavía no se puede evaluar optimización.");
  if (draft.successMetric.trim() && (!draft.baseline.trim() || !draft.target.trim())) assumptions.push("Métrica sin línea base actual y/o meta; no se puede afirmar mejora antes/después.");
  if (mapped.length < 2) assumptions.push("Agrega al menos dos elementos posicionales en fases explícitas para evaluar relaciones mirrorOf/creates entre elementos del proceso.");
  const names = mapped.map((item) => item.text.trim().toLowerCase());
  const duplicate = names.find((name, index) => name && names.indexOf(name) !== index);
  if (duplicate) conflicts.push(`«${duplicate}» aparece en más de un mapeo; confirma si representa la misma unidad o dos perspectivas distintas.`);
  if (!draft.constraints.trim()) conflicts.push("No hay restricciones registradas; ninguna regla propuesta puede asumir permisos, límites o excepciones.");
  if (mapped.length >= 2 && relations.length === 0 && mapped.every((item) => positionalIndex[item.perspective] !== undefined)) {
    assumptions.push("Con las posiciones y fases actuales no se deriva mirrorOf ni creates; se muestra none sin forzar una relación.");
  }

  const hasBaselineAndTarget = Boolean(draft.baseline.trim() && draft.target.trim());
  const confidence = Math.min(88, 42 + mapped.length * 5 + present.length * 3 + (draft.evidence.trim() ? 10 : 0) + (draft.expectedOutput.trim() ? 8 : 0) + (draft.successMetric.trim() ? 5 : 0) + (hasBaselineAndTarget ? 5 : 0));
  const confidenceReason = `${mapped.length} elemento(s) mapeado(s), ${present.length} de 5 perspectivas cubiertas${draft.evidence.trim() ? " y evidencia descrita" : " sin evidencia adjunta"}${hasBaselineAndTarget ? "; línea base y meta registradas" : "; falta línea base y/o meta medible"}. Índice heurístico de completitud, no probabilidad calibrada.`;
  const output = draft.expectedOutput.trim() || "el resultado esperado";
  const metric = draft.successMetric.trim();
  const metricClause = metric
    ? `Medir «${metric}» contra la línea base «${draft.baseline.trim() || "pendiente"}» y la meta «${draft.target.trim() || "pendiente"}»; no afirmar mejora antes de registrar resultados comparables.`
    : "Definir una métrica y línea base antes de afirmar que un resultado fue optimizado.";
  const mappingProposals: Proposal[] = mapped.map((item) => {
    const phase = item.phase ?? "adv";
    const perspectiveName = getPerspectiveName(item.perspective);
    const next = mapped.find((other) => other.id !== item.id);
    const action = item.perspective === "Ind"
      ? { kind: "Regla" as const, verb: "Conservar identidad", before: `«${item.text}» puede circular sin origen ni responsable visibles.`, after: `Registrar un identificador estable, origen y responsable para «${item.text}» antes de transformarlo.` }
      : item.perspective === "D"
      ? { kind: "Decisión" as const, verb: "Contrastar la diferencia", before: `La diferencia asociada con «${item.text}» no tiene un criterio explícito.`, after: `Comparar «${item.text}»${next ? ` con «${next.text}»` : " con su contraparte aún no mapeada"} y registrar el criterio antes de tomar una decisión.` }
      : item.perspective === "Tot"
      ? { kind: "Transformación" as const, verb: "Integrar en un sistema", before: `«${item.text}» se trata como un paso aislado.`, after: `Vincular «${item.text}» con el resultado «${output}» y conservar la relación entre entrada, regla y salida.` }
      : item.perspective === "Evol"
      ? { kind: "Transformación" as const, verb: "Proyectar hacia la salida", before: `No está descrito cómo «${item.text}» contribuye al resultado.`, after: `Especificar la transformación que lleva desde «${item.text}» hasta «${output}» y guardar su origen.` }
      : { kind: "Punto humano" as const, verb: "Preparar retorno y revisión", before: `No se ha descrito cómo revisar o revertir «${item.text}».`, after: `Definir una revisión o ruta de retorno para «${item.text}» y preservar el vínculo con la decisión que la originó.` };
    return {
      id: `map-${item.id}`,
      kind: action.kind,
      title: `${action.verb}: «${item.text}»`,
      before: action.before,
      after: action.after,
      source: `Elemento mapeado por el usuario: «${item.text}» → ${perspectiveName}, fase de ${phaseLabel(phase)}. Es una hipótesis de aplicación del proceso, no un resultado observado.`,
      confidence: draft.evidence.trim() ? "Respaldo medio" : "Respaldo bajo",
      confidenceReason: draft.evidence.trim() ? "Se describió evidencia, pero su contenido y relación causal no han sido evaluados." : "El texto proviene del mapeo del usuario; no se adjuntaron registros para validar su encaje.",
      status: "pending",
    };
  });
  const relationProposals: Proposal[] = relations.map((relation) => ({
    id: `review-${relation.id}`,
    kind: relation.type === "mirrorOf" ? "Regla" : "Decisión",
    title: `Revisar ${relation.type}: «${relation.sourceText}» → «${relation.targetText}»`,
    before: "La relación entre estos dos elementos no estaba trazada en la propuesta.",
    after: relation.type === "mirrorOf"
      ? `Comparar «${relation.sourceText}» con «${relation.targetText}» como posiciones espejo y conservar ambos orígenes antes de cerrar la transición.`
      : `Tratar el paso entre «${relation.sourceText}» y «${relation.targetText}» como transición lateral↔centro, registrando la condición de entrada y la decisión resultante.`,
    source: `Arista candidata calculada desde dos mapeos del proceso (${relation.sourceText}: ${getPerspectiveName(relation.sourcePerspective)}, ${phaseLabel(relation.sourcePhase)}; ${relation.targetText}: ${getPerspectiveName(relation.targetPerspective)}, ${phaseLabel(relation.targetPhase)}). Regla formal: ${relation.explanation}`,
    confidence: "Respaldo bajo",
    confidenceReason: "La regla se deriva de metadatos elegidos por el usuario; su significado de dominio no está validado.",
    status: "pending",
  }));
  const outputProposal: Proposal = {
    id: "outcome-check",
    kind: "Transformación",
    title: metric ? `Medir el resultado: «${metric}»` : "Definir una medida antes de optimizar",
    before: hasBaselineAndTarget ? `Línea base: ${draft.baseline.trim()} · Meta declarada: ${draft.target.trim()}.` : "No se registró una línea base y/o una meta cuantificable.",
    after: `Comprobar que ${output} cumple el criterio definido; guardar la entrada, las reglas aplicadas y el resultado comparable. ${metricClause}`,
    source: `Campos declarados por el usuario: resultado esperado «${draft.expectedOutput.trim() || "pendiente"}»${metric ? `; métrica «${metric}»` : "; no hay métrica"}.`,
    confidence: hasBaselineAndTarget && draft.evidence.trim() ? "Respaldo medio" : "Respaldo bajo",
    confidenceReason: hasBaselineAndTarget && draft.evidence.trim() ? "Hay valores declarados y evidencia descrita, pero la mejora aún requiere una medición independiente." : "Sin línea base, meta y evidencia verificable no se puede atribuir una mejora.",
    status: "pending",
  };
  const humanCheckpoint: Proposal = {
    id: "human-checkpoint",
    kind: "Punto humano",
    title: `Aprobar cambios antes de afectar «${draft.title.trim() || "este proceso"}»`,
    before: "No se conoce el riesgo de las excepciones o de los cambios irreversibles.",
    after: "Detener la transición y pedir autorización humana ante excepciones, restricciones no resueltas o una salida no contemplada.",
    source: `Salvaguarda del mapa: ${draft.constraints.trim() ? `revisar las restricciones «${draft.constraints.trim()}»` : "no se declararon restricciones"}. No se ejecuta ninguna acción externa.`,
    confidence: "Respaldo bajo",
    confidenceReason: "Control conservador; la app no conoce ni midió el nivel de riesgo operativo.",
    status: "pending",
  };
  const proposals = [...mappingProposals, ...relationProposals, outputProposal, humanCheckpoint];
  return { mappedCount: mapped.length, coverage, present, missing, assumptions, conflicts, relations, proposals, confidence, confidenceReason };
}

export function previewProcess(draft: ProcessDraft, proposal: Proposal): string {
  const processName = draft.title.trim() || "Proceso sin nombre";
  return `${processName}\n\n${proposal.after}\n\nTrazabilidad: ${proposal.source}`;
}
