import AsyncStorage from "@react-native-async-storage/async-storage";
import type { PerspectiveId, Phase } from "./iom-spec";

export type ProposalStatus = "pending" | "accepted" | "rejected";
export type Proposal = {
  id: string;
  kind: "Regla" | "Transformación" | "Decisión" | "Punto humano";
  title: string;
  before: string;
  after: string;
  source: string;
  confidence: "Respaldo bajo" | "Respaldo medio" | "Respaldo alto";
  confidenceReason: string;
  status: ProposalStatus;
};
export type ProcessDraft = {
  id: string;
  title: string;
  context: string;
  inputs: string;
  actors: string;
  constraints: string;
  expectedOutput: string;
  successMetric: string;
  baseline: string;
  target: string;
  evidence: string;
  mappings: { id: string; text: string; perspective: PerspectiveId; phase: Phase }[];
  proposals: Proposal[];
  createdAt: string;
  appliedAt?: string;
};

const DRAFT_KEY = "iomflow.process.v1";
const MODEL_KEY = "iomflow.training.v1";
export type TrainingReport = {
  trainedAt: string;
  algorithm: string;
  sampleCount: number;
  foldCount: number;
  accuracy: number;
  evidenceLabel: "Diagnóstico sintético circular";
};

export async function loadDraft(): Promise<ProcessDraft | null> {
  try {
    const raw = await AsyncStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<ProcessDraft>;
    return { ...createEmptyDraft(), ...parsed, mappings: (parsed.mappings ?? []).map((item) => ({ ...item, phase: item.phase ?? "adv" })), proposals: parsed.proposals ?? [] };
  } catch {
    return null;
  }
}

export async function saveDraft(draft: ProcessDraft): Promise<void> {
  await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
}

export async function loadTrainingReport(): Promise<TrainingReport | null> {
  try {
    const raw = await AsyncStorage.getItem(MODEL_KEY);
    return raw ? (JSON.parse(raw) as TrainingReport) : null;
  } catch {
    return null;
  }
}

export async function saveTrainingReport(report: TrainingReport): Promise<void> {
  await AsyncStorage.setItem(MODEL_KEY, JSON.stringify(report));
}

export function createEmptyDraft(): ProcessDraft {
  const now = new Date().toISOString();
  return {
    id: `process-${Date.now()}`,
    title: "",
    context: "",
    inputs: "",
    actors: "",
    constraints: "",
    expectedOutput: "",
    successMetric: "",
    baseline: "",
    target: "",
    evidence: "",
    mappings: [],
    proposals: [],
    createdAt: now,
  };
}
