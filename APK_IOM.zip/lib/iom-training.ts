import { TRIADS, type Phase, type PerspectiveId } from "./iom-spec";
import type { TrainingReport } from "./storage";

type Example = { triadIndex: number; phase: Phase; position: number; label: PerspectiveId };

function corpus(): Example[] {
  const examples: Example[] = [];
  for (const triad of TRIADS) {
    for (const phase of ["adv", "ret"] as const) {
      for (const position of [0, 1, 2]) {
        const label: PerspectiveId = position === 0 ? "Ind" : position === 1 ? "D" : "Tot";
        examples.push({ triadIndex: triad.index, phase, position, label });
      }
    }
  }
  return examples;
}

function fitNearestNeighbor(train: Example[], query: Example): PerspectiveId {
  const nearest = [...train].sort((a, b) => {
    const distanceA = (a.phase === query.phase ? 0 : 1) + Math.abs(a.position - query.position);
    const distanceB = (b.phase === query.phase ? 0 : 1) + Math.abs(b.position - query.position);
    return distanceA - distanceB;
  })[0];
  return nearest.label;
}

export function trainReferenceModel(): TrainingReport {
  const examples = corpus();
  let correct = 0;
  let total = 0;
  for (const heldOut of TRIADS) {
    const train = examples.filter((example) => example.triadIndex !== heldOut.index);
    const test = examples.filter((example) => example.triadIndex === heldOut.index);
    for (const query of test) {
      if (fitNearestNeighbor(train, query) === query.label) correct += 1;
      total += 1;
    }
  }
  return {
    trainedAt: new Date().toISOString(),
    algorithm: "k-NN (k = 1), características: fase y posición",
    sampleCount: examples.length,
    foldCount: TRIADS.length,
    accuracy: total === 0 ? 0 : correct / total,
    evidenceLabel: "Diagnóstico sintético circular",
  };
}
