export type PerspectiveId = "Ind" | "D" | "Tot" | "Evol" | "Invol";
export type Phase = "adv" | "ret";
export type RelationType = "mirrorOf" | "creates" | "none";

export const PERSPECTIVES: {
  id: PerspectiveId;
  name: string;
  kind: "posicional" | "vectorial";
  role: string;
  tone: string;
}[] = [
  { id: "Ind", name: "Individualidad", kind: "posicional", role: "Unidad y singularidad del fenómeno.", tone: "turquoise" },
  { id: "D", name: "Dualidad", kind: "posicional", role: "Diferencia, contraste y relación.", tone: "blue" },
  { id: "Tot", name: "Totalidad", kind: "posicional", role: "Integración del elemento en un sistema.", tone: "lime" },
  { id: "Evol", name: "Evolución", kind: "vectorial", role: "Flujo que proyecta del vacío hacia la estructura.", tone: "orange" },
  { id: "Invol", name: "Involución", kind: "vectorial", role: "Flujo que reorganiza o retorna desde la estructura.", tone: "purple" },
];

export const TRIADS: { index: number; advance: [string, string, string]; reverse: [string, string, string] }[] = [
  { index: 1, advance: ["orientación", "cuántico", "dirección"], reverse: ["dirección", "cuántico", "orientación"] },
  { index: 2, advance: ["hardware", "virtual", "software"], reverse: ["software", "virtual", "hardware"] },
  { index: 3, advance: ["universo", "espacio", "vacío"], reverse: ["vacío", "espacio", "universo"] },
  { index: 4, advance: ["singularidad", "tiempo", "infinito"], reverse: ["infinito", "tiempo", "singularidad"] },
  { index: 5, advance: ["cuerpo", "consciente", "mundo"], reverse: ["mundo", "consciente", "cuerpo"] },
  { index: 6, advance: ["carácter", "subconsciente", "personalidad"], reverse: ["personalidad", "subconsciente", "carácter"] },
  { index: 7, advance: ["memoria", "inconsciente", "imaginación"], reverse: ["imaginación", "inconsciente", "memoria"] },
  { index: 8, advance: ["receptor", "supraconsciente", "emisor"], reverse: ["emisor", "supraconsciente", "receptor"] },
  { index: 9, advance: ["lógica", "inteligencia", "libertad"], reverse: ["libertad", "inteligencia", "lógica"] },
  { index: 10, advance: ["muerte", "artificial", "vida"], reverse: ["vida", "artificial", "muerte"] },
  { index: 11, advance: ["descendente", "mente", "ascendente"], reverse: ["ascendente", "mente", "descendente"] },
  { index: 12, advance: ["oscuridad", "consciencia", "luz"], reverse: ["luz", "consciencia", "oscuridad"] },
  { index: 13, advance: ["animal", "humano", "IA"], reverse: ["IA", "humano", "animal"] },
];

export const OPERATION_STEPS = [
  { title: "Vacío informativo", detail: "Un contexto aún no estructurado.", mark: "○" },
  { title: "Distinción", detail: "Se identifica una unidad y su diferencia.", mark: "◌" },
  { title: "Relación", detail: "La diferencia se vincula con otra posición.", mark: "↔" },
  { title: "Integración", detail: "Los elementos se leen dentro de un sistema.", mark: "⊙" },
  { title: "Transformación", detail: "El sistema cambia, conservando trazabilidad.", mark: "↗" },
  { title: "Unidad autocontenida", detail: "La identidad puede seguirse a través del cambio.", mark: "◎" },
];

export function getPerspectiveName(id: PerspectiveId): string {
  return PERSPECTIVES.find((item) => item.id === id)?.name ?? id;
}

export function formalRelation(
  source: { phase: Phase; position: number },
  target: { phase: Phase; position: number },
): RelationType {
  if (source.phase === target.phase) return "none";
  if (target.position === 2 - source.position) return "mirrorOf";
  if ((source.position === 1) !== (target.position === 1)) return "creates";
  return "none";
}
